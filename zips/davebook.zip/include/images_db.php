<?php
require_once('connectvars.php');

function image_from_database() {
            // use a running counter for flow control of the outer loop
        $runningcount = 0;

			  // Connect to the database
			  $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

        $r = mysqli_query($dbc, "SELECT DISTINCT picture AS `img`, join_date FROM users WHERE picture IS NOT NULL AND picture !='' ORDER BY join_date DESC;")or die(mysqli_error());

            //Get # of images in results to use as upper limit for outer loop
        $img_ct = mysqli_num_rows($r);

        while ($runningcount <= $img_ct){

                    //rowcount reset to break content blocks
            $rowcount = 0;


            echo "<div class=\"row-fluid\">";

            $runningcount++;

                    while(($rowcount <= 3) && $row = mysqli_fetch_assoc($r))
            {
                    $rowcount++; 
                    $img = $row['img'];
                    echo '<div class="span2">';
                    echo "<span class='thumbnail'><img src='images/$img'/></span>"; //Photo # $runningcount of $img_ct</span>";
                    echo '</div>';
            }
            echo "</div>";

        }
}
?>