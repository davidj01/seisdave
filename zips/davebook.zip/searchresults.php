<?php

  require_once('appvars.php');
  require_once('connectvars.php');

  session_start();

  // If the session vars are not set, try to set them with a cookie
  if (!isset($_SESSION['id'])) {
    if (isset($_COOKIE['id']) && isset($_COOKIE['username'])) {
      $_SESSION['id'] = $_COOKIE['id'];
      $_SESSION['username'] = $_COOKIE['username'];
    }
  }
?>

<!DOCTYPE html">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Davebook - View Profile</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
  <div class="logo"><br /><br /><img src="images/davebook.png" />
	  <h4>If they're not on davebook they're not your friend.</h4>
	  <div class="bluebox"><a href="viewprofile.php">My Profile</a> &nbsp; | &nbsp;
	  <a href="viewallusers.php">View All Users</a> &nbsp; | &nbsp;
	  <a href="misc.php">Misc</a> &nbsp; | &nbsp;
	  <a href="logout.php">Log Out</a> <!-- (<?php echo $_SESSION['username'] ?>) -->
	  </div>
  </div>

<?php
	require_once('appvars.php');
	require_once('connectvars.php');

	// Connect to the database
	$dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

	if (isset($_POST['keyword'])) {
	// Filter
	$keyword = trim ($_POST['keyword']);

	// Select statement
	$search = "SELECT id, name FROM users WHERE name LIKE '%$keyword%'";
	// Display
	$result = mysqli_query($dbc, $search) or die('query did not work');
	if (!$result){
	echo "problem";
	exit();
	}

	  echo '<table>';
	  while ($row = mysqli_fetch_array($result)) {
		if (isset($_SESSION['id'])) {
		  echo '<td><a href="viewprofile.php?id=' . $row['id'] . '">' . $row['name'] . '</a></td></tr>';
		}
		else {
		  echo '<td>' . $row['name'] . '</td></tr>';
		}
	  }
	  echo '</table>';

	while($result_arr = mysqli_fetch_array( $result ))
	{
	echo $result_arr['name'];
	echo " ";
	echo "<br>";
	echo "<br>";
	}
	$anymatches=mysqli_num_rows($result);
	if ($anymatches == 0)
	{
	   echo "Nothing was found that matched your query.<br><br>";
	}
	}

	mysqli_close($dbc);
?>

</body>
</html>