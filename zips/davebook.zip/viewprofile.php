<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Davebook - View Profile</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet" media="screen">
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

<?php
  require_once('appvars.php');
  require_once('connectvars.php');
  session_start();
  // If the session vars are not set, try to set them with a cookie
  if (!isset($_SESSION['id'])) {
    if (isset($_COOKIE['id']) && isset($_COOKIE['username'])) {
      $_SESSION['id'] = $_COOKIE['id'];
      $_SESSION['username'] = $_COOKIE['username'];
    }
  }
?>

<body>
<div class="container">
  <div class="row">
    <div class="col-md-12">
			<div class="logo"><br /><br /><br /><img src="images/davebook.png" />
			  <h4>If they're not on davebook they're not your friend.</h4>
			</div>
		</div>
	</div>
</div>
<div><hr></div>
<nav class="navbar-wrapper navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
 
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
              <li class="active"><a href="viewprofile.php"><span class="glyphicon glyphicon-home"></span> My Profile</a></li>
              <li><a href="viewallusers.php"><span class="glyphicon glyphicon-star"></span> View All Users</a></li>
              <li class="dropdown">
                <a href="logout.php"><span class="glyphicon glyphicon-user"></span> Log Out</a></li>
            </ul>
          </div><!-- /.navbar-collapse -->
    </div>
</nav>


<div class="container">
  <div class="row">
    <div class="col-md-4">
	  <form method="post" action="searchresults.php">
		<input type="text" name="keyword" />
		<input type="submit" name="search" value="Search" />
	  </form>
    </div>
    <div class="col-md-4">&nbsp;&nbsp;&nbsp;Search using:&nbsp;&nbsp;<a href="searchajax1.htm"><strong>Ajax Search</strong></a>
    </div>
    <div class="col-md-4">&nbsp;&nbsp;&nbsp;Search using:&nbsp;&nbsp;<a href="searchajax2.htm"><strong>Ajax/Jquery Search</strong></a>
    </div>
  </div>
</div>

<div><hr></div>

<div class="container">
  <div class="row">
    <div class="col-md-4">
			<?php
			
			  // Make sure the user is logged in before going any further.
			  if (!isset($_SESSION['id'])) {
			    echo '<p class="login">Please <a href="index.php">log in</a> to access this page.</p>';
			    exit();
			  }
			  else {
			    echo('<p class="login">You are logged in as ' . $_SESSION['username'] . '.</p>');
			  }
			
			  // Connect to the database
			  $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
			
			  // Grab the profile data from the database
			  if (!isset($_GET['id'])) {
			    $query = "SELECT username, name, gender, birthdate, city, state, picture FROM users WHERE id = '" . $_SESSION['id'] . "'";
			  }
			  else {
			    $query = "SELECT username, name, gender, birthdate, city, state, picture FROM users WHERE id = '" . $_GET['id'] . "'";
			  }
			  $data = mysqli_query($dbc, $query);
			
			  if (mysqli_num_rows($data) == 1) {
			    // The user row was found so display the user data
			    $row = mysqli_fetch_array($data);
			    echo '<table>';
			    if (!empty($row['username'])) {
			      echo '<tr><td class="label">Username:</td><td>' . $row['username'] . '</td></tr>';
			    }
			    if (!empty($row['name'])) {
			      echo '<tr><td class="label">Name:</td><td>' . $row['name'] . '</td></tr>';
			    }
			    if (!empty($row['gender'])) {
			      echo '<tr><td class="label">Gender:</td><td>';
			      if ($row['gender'] == 'M') {
			        echo 'Male';
			      }
			      else if ($row['gender'] == 'F') {
			        echo 'Female';
			      }
			      else {
			        echo '?';
			      }
			      echo '</td></tr>';
			    }
			    if (!empty($row['birthdate'])) {
			      if (!isset($_GET['id']) || ($_SESSION['id'] == $_GET['id'])) {
			        // Show the user their own birthdate
			        echo '<tr><td class="label">Birthdate:</td><td>' . $row['birthdate'] . '</td></tr>';
			      }
			      else {
			        // Show only the birth year for everyone else
			        list($year, $month, $day) = explode('-', $row['birthdate']);
			        echo '<tr><td class="label">Year born:</td><td>' . $year . '</td></tr>';
			      }
			    }
			    if (!empty($row['city']) || !empty($row['state'])) {
			      echo '<tr><td class="label">Location:</td><td>' . $row['city'] . ', ' . $row['state'] . '</td></tr>';
			    }
			    if (!empty($row['picture'])) {
			      echo '<tr><td class="label">Picture:</td><td><img src="' . MM_UPLOADPATH . $row['picture'] .
			        '" alt="Profile Picture" /></td></tr>';
			    }
			    echo '</table>';
			    if (!isset($_GET['id']) || ($_SESSION['id'] == $_GET['id'])) {
			      echo '<p>Would you like to <a href="editprofile.php">edit your profile</a>?</p>';
			    }
			  } // End of check for a single row of user results
			  else {
			    echo '<p class="error">There was a problem accessing your profile.</p>';
			  }
			?>
    </div>

    <div class="col-md-4">
			<form method="post" action="messagepost.php">
			  <label for="other">Post a Message (4,000 character max):</label><br />
			  <textarea id="message" name="message" maxlength="4000" cols="25" rows="6"></textarea><br />
			  <input type="submit" name="submit" value="Submit" />
			</form>
			<?php
			  // Retrieve the friend data from MySQL
			  $query = "SELECT username, friend FROM relationships WHERE username = '" . $_SESSION['username'] . "'";
			  $data2 = mysqli_query($dbc, $query);
			
			  // Loop through the array of user data, formatting it as HTML
			  echo '<br /><h4><a href="viewmyfriends.php">My Friends:</a></h4>';
			  echo '<table>';
			  while ($row = mysqli_fetch_array($data2)) {
			    echo '<tr><td>' . $row['friend'] . '<br /><br /><br /></td></tr>';
			    }
			  echo '</table>';
			
			  mysqli_close($dbc);
			?>
    </div>

    <div class="col-md-4">
			<?php
			
			  // Connect to the database
			  $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
			
			  // Retrieve the message data from MySQL
			  $query = "select distinct username, date, message from messages where username = '" . $_SESSION['username'] . "' OR username in (select friend as username from relationships where username = '" . $_SESSION['username'] . "') order by date limit 25";
			  $data3 = mysqli_query($dbc, $query);
			
			  // Loop through the array of message data, formatting it as HTML
			  echo '<h4>Messages:</h4>';
			  echo '<table>';
			  while ($row = mysqli_fetch_array($data3)) {
			    echo '<tr><td>' . $row['username'] . ' &nbsp; ' . $row['date'] . '<br /><br />' . $row['message'] . '<br /><br /><br /></td></tr>';
			    }
			  echo '</table>';
			
			  mysqli_close($dbc);
			?>
    </div>
  </div>
</div>

    <script src="js/jquery-1.8.2.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/bootstrap.min.js"></script>
    
</body>
</html>
