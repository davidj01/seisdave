<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Davebook - View All Users</title>

    <!-- Bootstrap -->
    <link href="css/bootstrap.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

<?php
  session_start();

  // If the session vars are not set, try to set them with a cookie
  if (!isset($_SESSION['id'])) {
    if (isset($_COOKIE['id']) && isset($_COOKIE['username'])) {
      $_SESSION['id'] = $_COOKIE['id'];
      $_SESSION['username'] = $_COOKIE['username'];
    }
  }
?>

<body>
<div class="container">
  <div class="row">
    <div class="col-md-12">
			<div class="logo"><br /><br /><br /><img src="images/davebook.png" />
			  <h4>If they're not on davebook they're not your friend.</h4>
			</div>
		</div>
	</div>
</div>
<div><hr></div>
<nav class="navbar-wrapper navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
          </div>
 
          <!-- Collect the nav links, forms, and other content for toggling -->
          <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
              <li class="active"><a href="viewprofile.php"><span class="glyphicon glyphicon-home"></span> My Profile</a></li>
              <li><a href="viewallusers.php"><span class="glyphicon glyphicon-star"></span> View All Users</a></li>
              <li class="dropdown">
                <a href="logout.php"><span class="glyphicon glyphicon-user"></span> Log Out</a></li>
            </ul>
          </div><!-- /.navbar-collapse -->
    </div>
</nav>

<div class="container">
  <div class="row">
    <div class="col-md-4">
	  <form method="post" action="searchresults.php">
		<input type="text" name="keyword" />
		<input type="submit" name="search" value="Search" />
	  </form>
    </div>
    <div class="col-md-4">&nbsp;&nbsp;&nbsp;Search using:&nbsp;&nbsp;<a href="searchajax1.htm"><strong>Ajax Search</strong></a>
    </div>
    <div class="col-md-4">&nbsp;&nbsp;&nbsp;Search using:&nbsp;&nbsp;<a href="searchajax2.htm"><strong>Ajax/Jquery Search</strong></a>
    </div>
  </div>
</div>

<div><hr></div>
<div class="container">
    <h1 class="text-center">View All Users</h1>
    <hr>
            <?php
                    require_once 'include/images_db.php';
                    echo image_from_database();
            ?>
</div>

<?php
  require_once('appvars.php');
  require_once('connectvars.php');

  // Connect to the database
  $dbc = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

  // Retrieve the user data from MySQL
  $query = "SELECT id, name, picture FROM users WHERE name IS NOT NULL ORDER BY join_date DESC";
  $data = mysqli_query($dbc, $query);

  // Loop through the array of user data, formatting it as HTML
  echo '<div class="container">';
  echo '<h4>View All Users:</h4>';
  echo '<div class="table-responsive">';
  echo '<table class="table"><tr>';
  while ($row = mysqli_fetch_array($data)) {
    if (is_file(MM_UPLOADPATH . $row['picture']) && filesize(MM_UPLOADPATH . $row['picture']) > 0) {
      echo '<td><img src="' . MM_UPLOADPATH . $row['picture'] . '" alt="' . $row['name'] . '" /></td>';
    }
    else {
      echo '<td><img src="' . MM_UPLOADPATH . 'nopic.jpg' . '" alt="' . $row['name'] . '" /></td>';
    }
    if (isset($_SESSION['id'])) {
      echo '<td><a href="viewprofile.php?id=' . $row['id'] . '">' . $row['name'] . '</a><br /><br /><a href="addfriend.php?id=' . $row['id'] . '">Add Friend</a></td>';
    }
    else {
      echo '<td>' . $row['name'] . '</td>';
    }
  }
  echo '</tr></table>';
  echo '</div>';
  echo '</div>';
	
  mysqli_close($dbc);
?>
<!-- start: Java Script -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://code.jquery.com/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
<!-- end: Java Script -->
</body>
</html>